package com.example.training_app_list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingAppListApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingAppListApplication.class, args);
	}

}
