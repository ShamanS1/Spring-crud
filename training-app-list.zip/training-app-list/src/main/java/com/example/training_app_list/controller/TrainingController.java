package com.example.training_app_list.controller;

import com.example.training_app_list.entity.Training;
import com.example.training_app_list.service.TrainingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trainings")
public class TrainingController {

    @Autowired
    private TrainingService service;

    @PostMapping
    public ResponseEntity<Training> addTraining(@RequestBody Training training){
        return new ResponseEntity<>(service.addTraining(training), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Training>> getAllTraining(){
        return new ResponseEntity<>(service.getAllTraining(),HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Training> getById(@PathVariable Long id){
        Training training = service.getTrainingById(id);
        return (training!=null)? new ResponseEntity<>(training,HttpStatus.OK):new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/ponumber")
    public ResponseEntity<List<Training>> getByPoNumber(@RequestParam String PoNumber){
        return new ResponseEntity<>(service.getByPoNumber(PoNumber),HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteTraining(@PathVariable Long id){
        boolean val = service.deleteTraining(id);
        return (val)? new ResponseEntity<>(HttpStatus.OK): new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<Void> deleteByTrainerName(@RequestParam String trainerName){
        boolean val = service.deleteByName(trainerName);
        return (val)? new ResponseEntity<>(HttpStatus.OK): new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Training> updateTraining(@PathVariable Long id, @RequestBody Training training){
        Training updated = service.updateTraining(id,training);
        return (updated!=null)? new ResponseEntity<>(updated,HttpStatus.OK):new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
