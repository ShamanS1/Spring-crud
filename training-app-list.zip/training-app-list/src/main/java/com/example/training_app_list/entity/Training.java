package com.example.training_app_list.entity;

public class Training {
    private Long id;
    private String trainerName;
    private String trainingDetails;
    private String status;
    private double trainingAmount;
    private String poNumber;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public void setTrainerName(String trainerName) {
        this.trainerName = trainerName;
    }

    public String getTrainingDetails() {
        return trainingDetails;
    }

    public void setTrainingDetails(String trainingDetails) {
        this.trainingDetails = trainingDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTrainingAmount() {
        return trainingAmount;
    }

    public void setTrainingAmount(double trainingAmount) {
        this.trainingAmount = trainingAmount;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public Training(Long id, String trainerName, String trainingDetails, String status, double trainingAmount,String poNumber) {
        this.id = id;
        this.trainerName = trainerName;
        this.trainingDetails = trainingDetails;
        this.status = status;
        this.trainingAmount = trainingAmount;
        this.poNumber=poNumber;
    }
}
