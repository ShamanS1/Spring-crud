package com.example.training_app_list.service;

import com.example.training_app_list.entity.Training;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrainingService {

    List<Training> trainings = new ArrayList<>();
    long count= 1;

    public Training addTraining(Training training){
        training.setId(count++);
        trainings.add(training);
        return training;
    }

    public List<Training> getAllTraining(){
        return trainings;
    }

    public Training getTrainingById(long id){
        for(Training t:trainings){
            if(t.getId().equals(id))
                return t;
        }
        return null;
    }

    public List<Training> getByPoNumber(String PoNumber){
        List<Training> res = new ArrayList<>();
        for(Training t:trainings){
            if(t.getPoNumber().equalsIgnoreCase(PoNumber)){
                res.add(t);
            }
        }
        return res;
    }

    public boolean deleteTraining(Long id){
        return trainings.removeIf(t->t.getId().equals(id));
    }

    public boolean deleteByName(String name){
        return trainings.removeIf(t->t.getTrainerName().equalsIgnoreCase(name));
    }

    public Training updateTraining(Long id, Training updatedtraining){
        for(int i=0;i<trainings.size();i++){
            if(trainings.get(i).getId().equals(id)){
                updatedtraining.setId(id);
                trainings.set(i,updatedtraining);
                return  updatedtraining;
            }
        }
        return null;
    }
}
