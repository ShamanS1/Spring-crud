package com.example.training_app_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingAppListApplicationTests {

	@Test
	void contextLoads() {
	}

}
